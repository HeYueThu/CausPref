import torch


def cal_h_loss(dim: int, adj_matrix: torch.Tensor) -> torch.Tensor:
    cof = 1.0
    dim_float = float(dim)
    device = adj_matrix.device
    z: torch.Tensor = adj_matrix * adj_matrix
    z_in: torch.Tensor = torch.eye(dim).to(device)
    dag_loss: torch.Tensor = torch.tensor(dim_float).to(device)
    for i in range(1, dim + 1):
        z_in = torch.mm(z_in, z)

        # print(z_in.cpu())
        dag_loss += (1.0 / cof) * z_in.trace()
        cof *= float(i)

        if float(torch.mean(z_in).cpu()) > 90000.:
            # print('!!!!')
            break

    dag_loss -= dim_float
    return dag_loss


def BPR_loss(pos_scores: torch.Tensor, neg_scores: torch.Tensor) -> torch.Tensor:
    # loss = torch.mean(softplus(neg_scores - pos_scores))
    # loss = - torch.mean(torch.log2(torch.sigmoid(pos_scores - neg_scores)))
    loss = - torch.mean(torch.log2(torch.sigmoid(pos_scores - neg_scores)))
    return loss
