import datetime
from pprint import pprint

import numpy as np
import pandas as pd
import torch

from dataloader import DataLoaderCloudClick
from modules import LinearCausPref
from train import train_linear_CausPref
from utils import draw_loss_pic, is_dag, mkdir, get_label, \
    recall_precision_ATk, NDCGatK_r, mini_batch, draw_score_pic

ALL_DATA_PATH = './data/item_degree_bias/interactions.csv'
TRAIN_POS_DATA_PATH = './data/item_degree_bias/train.csv'
TRAIN_NEG_DATA_PATH = './data/item_degree_bias/neg_global.csv'
TEST_DATA_PATH = './data/item_degree_bias/test.csv'
SORTED_ITEMS = './data/item_degree_bias/sort_item_pca5_cg.csv'

batch_size = 8192
max_step = 8000
test_begin = 10

recommend_num_list = [50, 60]

adj_thr_list = [0.15]
test_batch_size = 2048
now_time = datetime.datetime.now()
time_str = now_time.strftime('%Y-%m-%d-%H-%M-%S')
result_path = 'CC_linear-CG-NCF-result/' + time_str + '/'
mkdir(result_path)

user_dim: int = 10
item_dim: int = 10
print('user feature: ')
user_columns = ['user_feature_{}'.format(i) for i in range(user_dim)]
print(user_columns)

print('item feature: ')
item_columns = ['item_feature_{}'.format(i) for i in range(item_dim)]
print(item_columns)

columns = user_columns + item_columns

data_loader: DataLoaderCloudClick = DataLoaderCloudClick(
    all_data_path=ALL_DATA_PATH,
    train_pos_data_path=TRAIN_POS_DATA_PATH,
    train_neg_data_path=TRAIN_NEG_DATA_PATH,
    sorted_items_feature_path=SORTED_ITEMS,
    test_data_path=TEST_DATA_PATH,
    user_columns=user_columns,
    item_columns=item_columns
)

para_dict: dict = {
    'bpr_coe': 1.0,
    'item_sparse_coe': 1.0,
    'lr': 0.0025,
    'need_preference_grad': True,
    'rec_coe': 0.5,
    'reg_alpha': 6.0,
    'u2i_sparse_coe': 1e-06
}

pprint(para_dict)

torch.cuda.set_device(0)
device: torch.device = torch.device('cuda')
print(torch.cuda.is_available())
print(device)

RANDOM_SEED = -1

RANDOM_SEED_LIST = [20000107, 20000412, 123456789, 456, 666]


def main(silent: bool = False):
    print('random seed:', RANDOM_SEED)
    assert RANDOM_SEED in RANDOM_SEED_LIST

    pos_data: pd.DataFrame = data_loader.train_pos_data
    neg_data: pd.DataFrame = data_loader.train_neg_data

    pos_data = pos_data[columns]
    neg_data = neg_data[columns]

    model: LinearCausPref = LinearCausPref(user_dim=user_dim, item_dim=item_dim, latent_dim=8)
    model = model.to(device)

    all_test_users_attr_tensor: torch.Tensor = torch.tensor(data_loader.all_test_users_attribute, dtype=torch.float32,
                                                            device=next(model.parameters()).device)
    all_items_attr_tensor: torch.Tensor = torch.tensor(data_loader.sorted_items_copy[item_columns].values,
                                                       dtype=torch.float32,
                                                       device=next(model.parameters()).device)

    pos_tensor: torch.Tensor = torch.tensor(pos_data.values, dtype=torch.float32,
                                            device=next(model.parameters()).device)

    neg_tensor: torch.Tensor = torch.tensor(neg_data.values, dtype=torch.float32,
                                            device=next(model.parameters()).device)

    pos_user_tensor: torch.Tensor = pos_tensor[:, 0: user_dim]
    pos_item_tensor: torch.Tensor = pos_tensor[:, user_dim: user_dim + item_dim]

    neg_user_tensor: torch.Tensor = neg_tensor[:, 0: user_dim]
    neg_item_tensor: torch.Tensor = neg_tensor[:, user_dim: user_dim + item_dim]

    bpr_list, rec_list, h_list, u2i_sparse_list, item_sparse_list = [], [], [], [], []

    test_precision_dict, test_recall_dict, test_ndcg_dict, test_step_dict = dict(), dict(), dict(), dict()

    for thr in adj_thr_list:
        test_precision_dict[thr] = []
        test_recall_dict[thr] = []
        test_ndcg_dict[thr] = []
        test_step_dict[thr] = []

    best_prec, best_recall, best_ndcg = dict(), dict(), dict()
    for thr in adj_thr_list:
        best_prec[thr] = [0. for i in range(len(recommend_num_list))]
        best_recall[thr] = [0. for i in range(len(recommend_num_list))]
        best_ndcg[thr] = [0. for i in range(len(recommend_num_list))]

    for step in range(max_step):
        if not silent:
            print('step: {} start'.format(step + 1))

        if step % 10 == 0 and step != 0 and step >= test_begin:
            model.eval()
            for thr in adj_thr_list:
                print('thr: ', thr)
                w_est = model.get_numpy_adj_matrix(threshold=thr, print_weight=False)
                print('is DAG ???   ', is_dag(w_est))
                precision, recall, ndcg = eval_recommend(model=model, thr=thr,
                                                         all_test_users_attr_tensor=all_test_users_attr_tensor,
                                                         all_items_attr_tensor=all_items_attr_tensor)

                test_precision_dict[thr].append(precision)
                test_recall_dict[thr].append(recall)
                test_ndcg_dict[thr].append(ndcg)
                test_step_dict[thr].append(step)

                # print(precision, recall)
                for i in range(len(recommend_num_list)):
                    best_prec[thr][i] = max(best_prec[thr][i], precision[i])
                    best_recall[thr][i] = max(best_recall[thr][i], recall[i])
                    best_ndcg[thr][i] = max(best_ndcg[thr][i], ndcg[i])

        bpr_loss, rec_loss, h_loss, u2i_sparse_loss, item_sparse = train_linear_CausPref(
            model, pos_user_tensor, pos_item_tensor,
            neg_user_tensor, neg_item_tensor,
            batch_size=batch_size, lr=para_dict['lr'], need_preference_grad=para_dict['need_preference_grad'],
            bpr_coe=para_dict['bpr_coe'], reg_alpha=para_dict['reg_alpha'],
            item_sparse_coe=para_dict['item_sparse_coe'], rec_coe=para_dict['rec_coe'],
            u2i_sparse_coe=para_dict['u2i_sparse_coe']
        )
        if not silent:
            print(
                'bpr_loss: {}, rec_loss: {}, h loss: {}, u2i sparse loss: {}, item_sparse: {}'.format(
                    bpr_loss, rec_loss, h_loss, u2i_sparse_loss, item_sparse))
        bpr_list.append(bpr_loss)
        rec_list.append(rec_loss)
        h_list.append(h_loss)
        u2i_sparse_list.append(u2i_sparse_loss)
        item_sparse_list.append(item_sparse)

    if not silent and len(RANDOM_SEED_LIST) < 5:
        print('draw pic')
        draw_loss_pic(max_step, filename=result_path + 'bpr_loss.png', bpr_loss=bpr_list)

        draw_loss_pic(max_step, filename=result_path + 'rec_loss.png', rec_loss=rec_list)

        draw_loss_pic(max_step, filename=result_path + 'h_loss.png', h_loss=h_list)

        draw_loss_pic(max_step, filename=result_path + 'u2i_parse_loss.png', u2i_parse_loss=u2i_sparse_list)

        draw_loss_pic(max_step, filename=result_path + 'item_sparse.png', item_sparse=item_sparse_list)

        for thr in adj_thr_list:
            draw_score_pic(test_step_dict[thr], title=str(thr), filename=result_path + 'precision.png',
                           precision=test_precision_dict[thr])

            draw_score_pic(test_step_dict[thr], title=str(thr), filename=result_path + 'recall.png',
                           recall=test_recall_dict[thr])

            draw_score_pic(test_step_dict[thr], title=str(thr), filename=result_path + 'ndcg.png',
                           ndcg=test_ndcg_dict[thr])

    for thr in adj_thr_list:
        print('\nthr: ', thr)
        w_est = model.get_numpy_adj_matrix(threshold=thr, print_weight=False)
        print('is DAG ???   ', is_dag(w_est))
        precision, recall, ndcg = eval_recommend(model=model, thr=thr,
                                                 all_test_users_attr_tensor=all_test_users_attr_tensor,
                                                 all_items_attr_tensor=all_items_attr_tensor)
        # print(precision, recall)
        for i in range(len(recommend_num_list)):
            best_prec[thr][i] = max(best_prec[thr][i], precision[i])
            best_recall[thr][i] = max(best_recall[thr][i], recall[i])
            best_ndcg[thr][i] = max(best_ndcg[thr][i], ndcg[i])

    print('best prec')
    pprint(best_prec)

    print('best recall')
    pprint(best_recall)

    print('best ndcg')
    pprint(best_ndcg)

    return best_prec, best_recall, best_ndcg


def eval_recommend(model: LinearCausPref, thr: float, all_test_users_attr_tensor, all_items_attr_tensor):
    # print(item_attr)
    model.eval()

    w_est: np.array = model.get_numpy_adj_matrix(threshold=thr, print_weight=False)
    if not is_dag(w_est):
        print('UNPREDICTABLE!!!!!')
        tmp_list = [0. for i in range(len(recommend_num_list))]
        return tmp_list, tmp_list, tmp_list

    pre_total, recall_total, ndcg_total = [], [], []

    for (batch_index, (batch_test_user, batch_test_user_id)) \
            in enumerate(mini_batch(test_batch_size, all_test_users_attr_tensor, data_loader.test_user_list)):
        rating_matrix: torch.Tensor = model.predict(batch_test_user, all_items_attr_tensor, thr)
        bought_users, bought_items = [], []

        for idx, user in enumerate(batch_test_user_id):
            bought_set_tmp: set = data_loader.user_bought_in_train(user)
            bought_users += [idx for i in range(len(bought_set_tmp))]
            bought_items += [item for item in bought_set_tmp]

        rating_matrix[bought_users, bought_items] = -(1 << 10)
        _, predict_items = torch.topk(rating_matrix, k=max(recommend_num_list))
        predict_items = predict_items.cpu().numpy()

        predict_items_list: list = []
        ground_truth_list: list = []

        for idx, user in enumerate(batch_test_user_id):
            predict_items_list.append(predict_items[idx])

            ground_truth: set = data_loader.user_test_ground_truth(user)

            ground_truth_list.append(ground_truth)

        r = get_label(ground_truth_list, predict_items_list)

        pre, recall, ndcg = [], [], []
        for k in recommend_num_list:
            ret = recall_precision_ATk(ground_truth_list, r, k)
            pre.append(ret['precision'])
            recall.append(ret['recall'])
            ret = NDCGatK_r(ground_truth_list, r, k)
            ndcg.append(ret)

        pre_total.append(pre)
        recall_total.append(recall)
        ndcg_total.append(ndcg)

    pre_np: np.array = np.sum(np.array(pre_total), axis=0) / data_loader.test_user_num
    recall_np: np.array = np.sum(np.array(recall_total), axis=0) / data_loader.test_user_num
    ndcg_np: np.array = np.sum(np.array(ndcg_total), axis=0) / data_loader.test_user_num

    pre_list = pre_np.tolist()
    recall_list = recall_np.tolist()
    ndcg_list = ndcg_np.tolist()

    prec_dict: dict = {}
    recall_dict: dict = {}
    ndcg_dict: dict = {}

    for idx, num in enumerate(recommend_num_list):
        prec_dict[num] = pre_list[idx]
        recall_dict[num] = recall_list[idx]
        ndcg_dict[num] = ndcg_list[idx]

    print('precision: ', prec_dict)
    print('recall: ', recall_dict)
    print('ndcg: ', ndcg_dict)

    return pre_list, recall_list, ndcg_list


if __name__ == '__main__':

    prec_list_dict, recall_list_dict, ndcg_list_dict = {}, {}, {}

    for thr in adj_thr_list:
        prec_list_dict[thr] = {}
        recall_list_dict[thr] = {}
        ndcg_list_dict[thr] = {}
        for i, num in enumerate(recommend_num_list):
            prec_list_dict[thr][num] = []
            recall_list_dict[thr][num] = []
            ndcg_list_dict[thr][num] = []

    for item in RANDOM_SEED_LIST:

        RANDOM_SEED = item
        torch.manual_seed(RANDOM_SEED)
        torch.cuda.manual_seed(RANDOM_SEED)
        np.random.seed(RANDOM_SEED)
        prec, recall, ndcg = main()

        for thr in adj_thr_list:
            for i, num in enumerate(recommend_num_list):
                prec_list_dict[thr][num].append(prec[thr][i])
                recall_list_dict[thr][num].append(recall[thr][i])
                ndcg_list_dict[thr][num].append(ndcg[thr][i])

    prec_result, recall_result, ndcg_result = {}, {}, {}
    for thr in adj_thr_list:
        prec_result[thr] = {}
        recall_result[thr] = {}
        ndcg_result[thr] = {}

    for thr in adj_thr_list:
        for i, num in enumerate(recommend_num_list):
            prec_result[thr][num] = {'avg': np.mean(prec_list_dict[thr][num]), 'var': np.var(prec_list_dict[thr][num])}
            recall_result[thr][num] = {'avg': np.mean(recall_list_dict[thr][num]),
                                       'var': np.var(recall_list_dict[thr][num])}
            ndcg_result[thr][num] = {'avg': np.mean(ndcg_list_dict[thr][num]), 'var': np.var(ndcg_list_dict[thr][num])}

    print('ndcg')
    for thr in adj_thr_list:
        print('thr ', thr)
        print(ndcg_result[thr])
    print()

    print('recall')
    for thr in adj_thr_list:
        print('thr ', thr)
        print(recall_result[thr])
    print()

    print('prec')
    for thr in adj_thr_list:
        print('thr ', thr)
        print(prec_result[thr])
    print()

    print()
    pprint(para_dict)
    print(ALL_DATA_PATH)
    print(RANDOM_SEED_LIST)
