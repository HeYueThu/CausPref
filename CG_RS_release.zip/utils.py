import datetime
import random
import time

import igraph as ig
import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
import seaborn as sns


def mini_batch(batch_size: int, *tensors):
    if len(tensors) == 1:
        tensor = tensors[0]
        for i in range(0, len(tensor), batch_size):
            yield tensor[i:i + batch_size]
    else:
        for i in range(0, len(tensors[0]), batch_size):
            yield tuple(x[i:i + batch_size] for x in tensors)


def progress_bar(now_index: int, total_num: int, start: float):
    total_num -= 1
    len = 20
    a = "*" * int((now_index + 1) / total_num * len)
    b = "." * int((max((total_num - now_index - 1), 0)) / total_num * len)
    c = (min(now_index + 1, total_num) / total_num) * 100
    dur = time.perf_counter() - start
    print("\r{:^3.0f}%[{}->{}]{:.2f}s".format(c, a, b, dur), end="")


def draw_loss_pic(max_step: int, filename: str, **losses):
    def random_color():
        color_arr = ['1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F']
        color = ""
        for i in range(6):
            color += color_arr[random.randint(0, 14)]
        return "#" + color

    plt.figure()
    for key in losses.keys():
        plt.plot(range(1, max_step + 1), losses[key], color=random_color(), label=key)

    plt.legend()
    plt.savefig(filename)
    plt.show()


def draw_score_pic(x: list, title: str, filename: str, **losses):
    def random_color():
        color_arr = ['1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F']
        color = ""
        for i in range(6):
            color += color_arr[random.randint(0, 14)]
        return "#" + color

    plt.figure()
    for key in losses.keys():
        plt.plot(x, losses[key], color=random_color(), label=key)

    plt.legend()
    plt.savefig(filename)
    plt.show()


def is_dag(W):
    G = ig.Graph.Weighted_Adjacency(W.tolist())
    return G.is_dag()


def mkdir(path):
    import os

    path = path.strip()
    path = path.rstrip("\\")
    isExists = os.path.exists(path)

    if not isExists:
        os.makedirs(path)
        return True
    else:
        return False


def draw_graph_heat_map(adj_matrix: np.ndarray, filename: str, title=None, show=False, vmax=None, vmin=None):
    cmap = sns.color_palette('Reds')
    sns.heatmap(adj_matrix, cmap=cmap, vmax=vmax, vmin=vmin)
    if title is not None:
        plt.title(title)
    plt.savefig(filename)
    if show:
        plt.show()
    plt.close()


def get_now_time_str():
    now_time = datetime.datetime.now()
    time_str = now_time.strftime('%Y-%m-%d-%H-%M-%S')
    return time_str


def save_loss_list(filename: str, **losses):
    with open(filename, 'w') as output:
        for key in losses.keys():
            output.write(key+'\n')
            output.write(str(losses[key]))
            output.write('\n\n')
        output.close()


def build_paras_str(para_dict: dict) -> str:
    result: str = ''
    for key in para_dict.keys():
        result += (key + '=' + str(para_dict[key]) + '_')

    return result[: -1]


def locate_sub_matrix(matrix, line_indexs: list, column_indexs: list):
    line = matrix[line_indexs, :]
    return line[:, column_indexs]


def has_i2u(adj_matrix: np.ndarray, user_slice: tuple, item_slice: tuple) -> bool:
    abs_matrix = np.abs(adj_matrix)
    user_start, user_end = user_slice[0], user_slice[1]
    item_start, item_end = item_slice[0], item_slice[1]

    item_lines = abs_matrix[item_start:item_end, :]
    i2u = item_lines[:, user_start:user_end]
    return np.sum(i2u) != 0.


def exist_root_item(adj_matrix: np.ndarray, item_slice: tuple) -> bool:
    abs_matrix = np.abs(adj_matrix)
    item_start, item_end = item_slice[0], item_slice[1]

    for column_id in range(item_start, item_end):
        column = abs_matrix[:, column_id]
        if np.sum(column) == 0.:
            return True
    return False


def item_unpredictable(adj_matrix: np.ndarray, user_slice: tuple, item_slice: tuple) -> bool:
    if not is_dag(adj_matrix):
        return True
    return has_i2u(adj_matrix, user_slice=user_slice, item_slice=item_slice) | exist_root_item(adj_matrix, item_slice)


def get_label(test_data, pred_data):
    r = []
    for i in range(len(test_data)):
        groundTrue = test_data[i]
        predictTopK = pred_data[i]
        pred = list(map(lambda x: x in groundTrue, predictTopK))
        pred = np.array(pred).astype("float")
        r.append(pred)
    return np.array(r).astype('float')


def recall_precision_ATk(test_data, r, k):
    right_pred = r[:, :k].sum(1)
    precis_n = np.array([k for i in range(len(test_data))])
    recall_n = np.array([len(test_data[i]) for i in range(len(test_data))])
    recall = np.sum(right_pred / recall_n)
    precis = np.sum(right_pred / precis_n)

    return {'recall': recall, 'precision': precis}


def NDCGatK_r(test_data, r, k):
    """
    Normalized Discounted Cumulative Gain
    """
    assert len(r) == len(test_data)
    pred_data = r[:, :k]

    test_matrix = np.zeros((len(pred_data), k))
    for i, items in enumerate(test_data):
        length = k if k <= len(items) else len(items)
        test_matrix[i, :length] = 1
    max_r = test_matrix
    idcg = np.sum(max_r * 1./np.log2(np.arange(2, k + 2)), axis=1)
    dcg = pred_data*(1./np.log2(np.arange(2, k + 2)))
    dcg = np.sum(dcg, axis=1)
    idcg[idcg == 0.] = 1.
    ndcg = dcg/idcg
    ndcg[np.isnan(ndcg)] = 0.
    return np.sum(ndcg)

