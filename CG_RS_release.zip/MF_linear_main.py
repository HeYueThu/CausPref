import datetime
import json

import torch
import numpy as np

from dataloader import DataLoaderCloudClick
from modules import MFLinear
import pandas as pd

from train import train_linear_Neural_CF
from utils import draw_loss_pic, mkdir, mini_batch, get_label, \
    recall_precision_ATk, NDCGatK_r


ALL_DATA_PATH = './data/item_degree_bias/interactions.csv'
TRAIN_POS_DATA_PATH = './data/item_degree_bias/train.csv'
TRAIN_NEG_DATA_PATH = './data/item_degree_bias/neg_global.csv'
TEST_DATA_PATH = './data/item_degree_bias/test.csv'
SORTED_ITEMS = './data/item_degree_bias/sort_item_pca5_cg.csv'


# TEST_DATA_PATH = './data0308/area-test-0310.csv'
learning_rate = 0.001
batch_size = 2048
test_batch_size = 2048
# test_batch_size = 2048
max_step = 8000
begin_test = 10
recommend_num_list = [50, 60]

now_time = datetime.datetime.now()
time_str = now_time.strftime('%Y-%m-%d-%H-%M-%S')
result_path = 'CC_linear-NCF-result/' + time_str + '/'
mkdir(result_path)

torch.cuda.set_device(0)
device: torch.device = torch.device('cuda')
print(torch.cuda.is_available())
print(device)

user_dim: int = 10
item_dim: int = 10
print('user feature: ')
user_columns = ['user_feature_{}'.format(i) for i in range(user_dim)]
print(user_columns)

print('item feature: ')
item_columns = ['item_feature_{}'.format(i) for i in range(item_dim)]
print(item_columns)

columns = user_columns + item_columns

data_loader: DataLoaderCloudClick = DataLoaderCloudClick(
    all_data_path=ALL_DATA_PATH,
    train_pos_data_path=TRAIN_POS_DATA_PATH,
    train_neg_data_path=TRAIN_NEG_DATA_PATH,
    test_data_path=TEST_DATA_PATH,
    sorted_items_feature_path=SORTED_ITEMS,
    user_columns=user_columns,
    item_columns=item_columns
)

all_data: pd.DataFrame = data_loader.all_data
# shop_pool = all_data.drop_duplicates(['item_id'])
# train_data: pd.DataFrame = pd.read_csv(TRAIN_POS_DATA_PATH)

RANDOM_SEED = -1

RANDOM_SEED_LIST = [17373331, 17373522, 666]
# RANDOM_SEED_LIST = [17373522, 17373331]


def main(silent: bool = False):

    print('random seed:', RANDOM_SEED)
    assert RANDOM_SEED in RANDOM_SEED_LIST

    pos_data: pd.DataFrame = data_loader.train_pos_data
    neg_data: pd.DataFrame = data_loader.train_neg_data

    model: MFLinear = MFLinear(user_dim=user_dim, item_dim=item_dim, latent_dim=8)

    model = model.to(device)

    pos_data = pos_data[columns]
    neg_data = neg_data[columns]

    pos_tensor: torch.Tensor = torch.tensor(pos_data.values, dtype=torch.float32,
                                            device=next(model.parameters()).device)

    neg_tensor: torch.Tensor = torch.tensor(neg_data.values, dtype=torch.float32,
                                            device=next(model.parameters()).device)

    pos_user_tensor: torch.Tensor = pos_tensor[:, 0: user_dim]
    pos_item_tensor: torch.Tensor = pos_tensor[:, user_dim: user_dim + item_dim]

    neg_user_tensor: torch.Tensor = neg_tensor[:, 0: user_dim]
    neg_item_tensor: torch.Tensor = neg_tensor[:, user_dim: user_dim + item_dim]

    bpr_list, pos_list, neg_list = [], [], []

    best_prec, best_recall, best_ndcg = [0. for i in range(len(recommend_num_list))], \
                                        [0. for i in range(len(recommend_num_list))], \
                                        [0. for i in range(len(recommend_num_list))]
    for step in range(max_step):

        if step % 10 == 0 and step >= begin_test:
            precision, recall, ndcg = eval(model=model)

            for i in range(len(recommend_num_list)):
                best_prec[i] = max(best_prec[i], precision[i])
                best_recall[i] = max(best_recall[i], recall[i])
                best_ndcg[i] = max(best_ndcg[i], ndcg[i])

        if not silent:
            print('step: {} start'.format(step + 1))

        bpr_loss, pos_score, neg_score = train_linear_Neural_CF(model, pos_user_tensor, pos_item_tensor,
                                                                neg_user_tensor, neg_item_tensor,
                                                                lr=learning_rate, batch_size=batch_size)

        if not silent:
            print('bpr_loss: {}, pos score: {}, neg score: {}'.format(bpr_loss, pos_score, neg_score))
        bpr_list.append(bpr_loss)
        pos_list.append(pos_score)
        neg_list.append(neg_score)

    if not silent and len(RANDOM_SEED_LIST) < 5:
        draw_loss_pic(max_step, filename=result_path + 'bpr_loss.png', bpr_loss=bpr_list)

        draw_loss_pic(max_step, filename=result_path + 'pos.png', pos=pos_list)

        draw_loss_pic(max_step, filename=result_path + 'neg.png', neg=neg_list)

    # exit()

    precision, recall, ndcg = eval(model=model)

    for i in range(len(recommend_num_list)):
        best_prec[i] = max(best_prec[i], precision[i])
        best_recall[i] = max(best_recall[i], recall[i])
        best_ndcg[i] = max(best_ndcg[i], ndcg[i])

    prec_dict: dict = {}
    recall_dict: dict = {}
    ndcg_dict: dict = {}

    for idx, num in enumerate(recommend_num_list):
        prec_dict[num] = best_prec[idx]
        recall_dict[num] = best_recall[idx]
        ndcg_dict[num] = best_ndcg[idx]

    print()
    print('best precision: ', prec_dict)
    print('best recall: ', recall_dict)
    print('best ndcg: ', ndcg_dict)

    result: dict = {'precision': prec_dict, 'recall': recall_dict, 'ndcg': ndcg_dict}
    return prec_dict, recall_dict, ndcg_dict


def eval(model: MFLinear, silent: bool = False):
    # print(item_attr)
    model.eval()
    if not silent:
        out = open(result_path + 'rec.txt', 'w')
    # print('user num: {}'.format(len(user_attribute)))
    # print('item num: {}'.format(len(item_attr)))

    all_test_users_attr_tensor: torch.Tensor = torch.tensor(data_loader.all_test_users_attribute, dtype=torch.float32,
                                                            device=next(model.parameters()).device)
    all_items_attr_tensor: torch.Tensor = torch.tensor(data_loader.sorted_items_copy[item_columns].values,
                                                       dtype=torch.float32,
                                                       device=next(model.parameters()).device)

    pre_total, recall_total, ndcg_total = [], [], []

    for (batch_index, (batch_test_user, batch_test_user_id)) \
            in enumerate(mini_batch(test_batch_size, all_test_users_attr_tensor, data_loader.test_user_list)):
        rating_matrix: torch.Tensor = model.get_user_ratings(batch_test_user, all_items_attr_tensor)
        bought_users, bought_items = [], []

        for idx, user in enumerate(batch_test_user_id):
            bought_set_tmp: set = data_loader.user_bought_in_train(user)
            bought_users += [idx for i in range(len(bought_set_tmp))]
            bought_items += [item for item in bought_set_tmp]

        rating_matrix[bought_users, bought_items] = -(1 << 10)
        _, predict_items = torch.topk(rating_matrix, k=max(recommend_num_list))
        predict_items = predict_items.cpu().numpy()

        predict_items_list: list = []
        ground_truth_list: list = []

        for idx, user in enumerate(batch_test_user_id):
            predict_items_list.append(predict_items[idx])

            ground_truth: set = data_loader.user_test_ground_truth(user)

            ground_truth_list.append(ground_truth)

        r = get_label(ground_truth_list, predict_items_list)

        pre, recall, ndcg = [], [], []
        for k in recommend_num_list:
            ret = recall_precision_ATk(ground_truth_list, r, k)
            pre.append(ret['precision'])
            recall.append(ret['recall'])
            ret = NDCGatK_r(ground_truth_list, r, k)
            ndcg.append(ret)

        pre_total.append(pre)
        recall_total.append(recall)
        ndcg_total.append(ndcg)

    pre_np: np.array = np.sum(np.array(pre_total), axis=0) / data_loader.test_user_num
    recall_np: np.array = np.sum(np.array(recall_total), axis=0) / data_loader.test_user_num
    ndcg_np: np.array = np.sum(np.array(ndcg_total), axis=0) / data_loader.test_user_num

    pre_list = pre_np.tolist()
    recall_list = recall_np.tolist()
    ndcg_list = ndcg_np.tolist()

    prec_dict: dict = {}
    recall_dict: dict = {}
    ndcg_dict: dict = {}

    for idx, num in enumerate(recommend_num_list):
        prec_dict[num] = pre_list[idx]
        recall_dict[num] = recall_list[idx]
        ndcg_dict[num] = ndcg_list[idx]

    print('precision: ', prec_dict)
    print('recall: ', recall_dict)
    print('ndcg: ', ndcg_dict)

    return pre_list, recall_list, ndcg_list


if __name__ == '__main__':

    prec_list_dict, recall_list_dict, ndcg_list_dict = {}, {}, {}

    for num in recommend_num_list:
        prec_list_dict[num] = []
        recall_list_dict[num] = []
        ndcg_list_dict[num] = []

    for item in RANDOM_SEED_LIST:
        RANDOM_SEED = item
        torch.manual_seed(RANDOM_SEED)
        torch.cuda.manual_seed(RANDOM_SEED)
        np.random.seed(RANDOM_SEED)

        prec, recall, ndcg = main(silent=True)
        # print(prec, recall, ndcg)
        for num in recommend_num_list:
            prec_list_dict[num].append(prec[num])
            recall_list_dict[num].append(recall[num])
            ndcg_list_dict[num].append(ndcg[num])

    prec_result, recall_result, ndcg_result = {}, {}, {}

    for num in recommend_num_list:

        recall_result[num] = {
            'avg': np.mean(recall_list_dict[num]),
            'var': np.var(recall_list_dict[num])
        }

        ndcg_result[num] = {
            'avg': np.mean(ndcg_list_dict[num]),
            'var': np.var(ndcg_list_dict[num])
        }

        prec_result[num] = {
            'avg': np.mean(prec_list_dict[num]),
            'var': np.var(prec_list_dict[num])
        }
    print()
    print()
    print('ndcg: ', ndcg_result)
    print('recall: ', recall_result)
    print('prec: ', prec_result)
    print(RANDOM_SEED_LIST)
