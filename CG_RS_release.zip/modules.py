import copy
import math

from torch import nn
import torch
import numpy as np


class BasicModel(nn.Module):
    def __init__(self):
        super(BasicModel, self).__init__()

    def forward(self, *samples):
        raise NotImplementedError

    def get_numpy_adj_matrix(self) -> np.ndarray:
        raise NotImplementedError

    def get_tensor_adj_matrix(self) -> torch.Tensor:
        raise NotImplementedError


class LinearCG(BasicModel):
    def __init__(self, user_dim: int, item_dim: int):
        super(LinearCG, self).__init__()

        self.user_dim = user_dim
        self.item_dim = item_dim
        self.adj_dim = item_dim
        self.adj_matrix: torch.nn.Parameter = torch.nn.Parameter(torch.rand((self.item_dim, self.item_dim)),
                                                                 requires_grad=True)
        self.user2item: torch.nn.Sequential = torch.nn.Sequential(
            nn.Linear(self.user_dim, self.item_dim, bias=False)
        )
        self.__init_weight()

    def __init_weight(self):
        nn.init.normal_(self.adj_matrix, std=0.15)

    def forward(self, user_samples: torch.Tensor, item_samples: torch.Tensor,
                need_preference_grad: bool = True):
        assert user_samples.shape[0] == item_samples.shape[0]

        if need_preference_grad:
            user2item_causal_graph: torch.nn.Sequential = self.user2item
            item_causal_graph: torch.nn.Parameter = self.adj_matrix
        else:
            user2item_causal_graph: torch.nn.Sequential = copy.deepcopy(self.user2item)
            item_causal_graph: torch.nn.Parameter = self.adj_matrix.detach()

        user2item_vector: torch.Tensor = user2item_causal_graph(user_samples)

        item2item_vector: torch.Tensor = torch.mm(item_samples, item_causal_graph)

        user_preference: torch.Tensor = user2item_vector + item2item_vector
        return user_preference

    def get_numpy_adj_matrix(self, threshold: float = 0.3,
                             need_threshold: bool = True, print_weight: bool = True) -> np.ndarray:
        w_est: np.ndarray = self.adj_matrix.cpu().detach().numpy().copy()
        if not need_threshold:
            return w_est
        if print_weight:
            print(w_est)
        w_est[np.abs(w_est) < threshold] = 0
        return w_est

    def get_tensor_adj_matrix(self) -> torch.Tensor:
        """
        :return: adj matrix. CAREFUL! this tensor is in the device where the model be. so you should check the device!
        """
        return self.adj_matrix

    def predict(self, users_attr: torch.Tensor, adj_thr: float):
        assert len(users_attr.shape) == 2
        # print(users_attr.shape, items_attr.shape)
        adj_matrix: np.array = self.get_numpy_adj_matrix(threshold=adj_thr, print_weight=False)
        user2item_vector: torch.Tensor = self.user2item(users_attr)
        known_nodes: set = set()

        for item_node in range(adj_matrix.shape[0]):
            has_parent = False
            for edg in range(adj_matrix.shape[1]):
                if adj_matrix[edg][item_node] != 0.:
                    has_parent = True
                    break
            if not has_parent:
                known_nodes.add(item_node)
        assert len(known_nodes) > 0

        cnt = adj_matrix.shape[0] - len(known_nodes)

        while cnt > 0:
            node_to_predict = -1
            for node in range(adj_matrix.shape[0]):
                if node in known_nodes:
                    continue
                has_unknown_parent = False
                for edg in range(adj_matrix.shape[1]):
                    if adj_matrix[edg][node] != 0 and (edg not in known_nodes):
                        has_unknown_parent = True
                        break
                if has_unknown_parent:
                    continue
                node_to_predict = node
                break
            assert node_to_predict != -1

            for edg in range(adj_matrix.shape[0]):
                if adj_matrix[edg][node_to_predict] == 0:
                    continue
                user2item_vector[:, node_to_predict:node_to_predict+1] += \
                    user2item_vector[:, edg:edg+1] * adj_matrix[edg][node_to_predict]
            cnt -= 1
        return user2item_vector


class LinearCausPref(BasicModel):
    def __init__(self, user_dim: int, item_dim: int, latent_dim: int):
        super(LinearCausPref, self).__init__()

        self.user_dim = user_dim
        self.item_dim = item_dim
        self.user_pref_dim = item_dim
        self.causal_graph: LinearCG = LinearCG(self.user_dim, self.item_dim)

        self.user_encoder: nn.Sequential = nn.Sequential(
            nn.Linear(self.user_pref_dim, latent_dim, bias=True),
        )

        self.item_encoder: nn.Sequential = nn.Sequential(
            nn.Linear(item_dim, latent_dim, bias=True),
        )

    def forward(self, user_samples: torch.Tensor, item_samples: torch.Tensor,
                need_preference_grad: bool = True, need_user_pref: bool = False):
        assert user_samples.shape[0] == item_samples.shape[0]

        user_pref: torch.Tensor = self.causal_graph(user_samples, item_samples, need_preference_grad)

        user_embedding: torch.Tensor = self.user_encoder(user_pref)

        item_embedding: torch.Tensor = self.item_encoder(item_samples)

        if need_user_pref:
            return torch.sum(user_embedding * item_embedding, dim=1), user_pref
        else:
            return torch.sum(user_embedding * item_embedding, dim=1)

    def get_numpy_adj_matrix(self, threshold: float = 0.3,
                             need_threshold: bool = True, print_weight: bool = True) -> np.ndarray:
        return self.causal_graph.get_numpy_adj_matrix(threshold, need_threshold, print_weight)

    def get_tensor_adj_matrix(self) -> torch.Tensor:
        """
        :return: adj matrix. CAREFUL! this tensor is in the device where the model be. so you should check the device!
        """
        return self.causal_graph.get_tensor_adj_matrix()

    def predict(self, users_attr: torch.Tensor, items_attr: torch.Tensor, adj_thr: float):
        assert len(users_attr.shape) == 2 and len(items_attr.shape) == 2

        user_pref_tensor: torch.Tensor = self.causal_graph.predict(users_attr, adj_thr)

        user_embedding: torch.Tensor = self.user_encoder(user_pref_tensor)

        item_embedding: torch.Tensor = self.item_encoder(items_attr)

        return torch.matmul(user_embedding, item_embedding.t())


class MFLinear(nn.Module):
    def __init__(self, user_dim: int, item_dim: int, latent_dim: int):
        super(MFLinear, self).__init__()
        self.user_encoder: nn.Sequential = nn.Sequential(nn.Linear(user_dim, latent_dim, bias=True))
        self.item_encoder: nn.Sequential = nn.Sequential(nn.Linear(item_dim, latent_dim, bias=True))
        self.user_dim = user_dim
        self.item_dim = item_dim
        self.latent_dim = latent_dim

    def forward(self, user_samples: torch.Tensor, item_samples: torch.Tensor):
        assert user_samples.shape[0] == item_samples.shape[0]
        user_embedding: torch.Tensor = self.user_encoder(user_samples)
        item_embedding: torch.Tensor = self.item_encoder(item_samples)
        return torch.sum(user_embedding * item_embedding, dim=1)

    def get_user_ratings(self, users_feature: torch.Tensor, all_items_feature: torch.Tensor):
        """
        make sure each line represent different user, and you know the map!
        :param users_feature:
        :param all_items_feature:
        :return:
        """
        users_emb: torch.Tensor = self.user_encoder(users_feature)
        items_emb: torch.Tensor = self.item_encoder(all_items_feature)
        return torch.matmul(users_emb, items_emb.t())
