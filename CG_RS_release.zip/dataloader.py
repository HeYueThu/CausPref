from datetime import datetime

import numpy as np
import pandas as pd
from tqdm import tqdm


class DataLoaderCloudClick(object):
    def __init__(
            self, all_data_path, train_pos_data_path,
            train_neg_data_path, test_data_path, sorted_items_feature_path,
            user_columns: list, item_columns: list,
    ):
        print('begin init data loader', datetime.now())
        print('begin read csv', datetime.now())
        self.all_data: pd.DataFrame = pd.read_csv(all_data_path)
        self.train_pos_data: pd.DataFrame = pd.read_csv(train_pos_data_path)
        self.train_neg_data: pd.DataFrame = pd.read_csv(train_neg_data_path)
        # print('test only 3k!!!!')
        self.test_data: pd.DataFrame = pd.read_csv(test_data_path)[:3000]
        self.sorted_items: pd.DataFrame = pd.read_csv(sorted_items_feature_path)

        print('begin analysis data', datetime.now())

        self.user_columns = user_columns
        self.item_columns = item_columns

        self.user_list: list = list(self.all_data.drop_duplicates(['user_id'])['user_id'])
        print('total user num: {}'.format(len(self.user_list)))
        self.user_bought_dict_in_train: dict = dict()

        for user in self.user_list:
            self.user_bought_dict_in_train[user] = set()

        with open(train_pos_data_path, 'r') as f:
            f.readline()
            lines: list = f.readlines()
            for line in tqdm(lines):
                line = line.strip()
                elements = line.split(',')
                user = int(elements[0])
                if self.user_bought_dict_in_train.get(user, None) is None:
                    self.user_bought_dict_in_train[user] = set()
                self.user_bought_dict_in_train[user].add(int(elements[1]))

        self.test_user_list: list = list(self.test_data.drop_duplicates(['user_id'])['user_id'])

        self.train_user_list: list = list(self.train_pos_data.drop_duplicates(['user_id'])['user_id'])

        self.user_bought_dict_ground_truth: dict = dict()

        for idx, row in tqdm(self.test_data.iterrows()):
            user = int(row['user_id'])
            if self.user_bought_dict_ground_truth.get(user, None) is None:
                self.user_bought_dict_ground_truth[user] = set()
            self.user_bought_dict_ground_truth[user].add(int(row['item_id']))

        self.test_users_attribute: dict = {}

        tmp_user_attr: pd.DataFrame = self.test_data.drop_duplicates(['user_id'])

        for idx, row in tqdm(tmp_user_attr.iterrows()):
            user = int(row['user_id'])
            self.test_users_attribute[user] = row[user_columns].values

        self.all_test_users_attr: list = []
        for user in self.test_user_list:
            self.all_test_users_attr.append(list(self.test_users_attribute[user]))

        self.test_users_bought_in_train_user: list = []
        self.test_users_bought_in_train_item: list = []
        for idx, user in enumerate(self.test_user_list):
            self.test_users_bought_in_train_user += [idx] * len(self.user_bought_dict_in_train[user])
            self.test_users_bought_in_train_item += list(self.user_bought_dict_in_train[user])
        assert len(self.test_users_bought_in_train_user) == len(self.test_users_bought_in_train_item)

        print('data loader init finish', datetime.now())
        print('test user num: ', self.test_user_num)
        print('items num: ', self.sorted_items.shape[0])

    def user_bought_in_train(self, user_id) -> set:
        return self.user_bought_dict_in_train[user_id]

    def user_test_ground_truth(self, user_id) -> set:
        return self.user_bought_dict_ground_truth[user_id]

    def get_test_user_attr(self, user_id) -> np.ndarray:
        return self.test_users_attribute[user_id]

    @property
    def all_items_attribute_pd(self) -> pd.DataFrame:
        return self.sorted_items

    @property
    def test_user_num(self):
        return len(self.test_user_list)

    @property
    def all_test_users_attribute(self):
        return self.all_test_users_attr

    @property
    def sorted_items_copy(self):
        return self.sorted_items

    @property
    def test_users_bought_in_train_list_pair(self):
        return self.test_users_bought_in_train_user, self.test_users_bought_in_train_item
