import torch
from torch import nn

from loss import cal_h_loss, BPR_loss
from modules import LinearCausPref, MFLinear
from utils import mini_batch


def train_linear_CausPref(
        model: LinearCausPref,
        pos_users_tensor: torch.Tensor, pos_items_tensor: torch.Tensor,
        neg_users_tensor: torch.Tensor, neg_items_tensor: torch.Tensor,
        lr: float = 0.001, batch_size: int = 256, need_preference_grad=True,
        bpr_coe: float = 1.0, rec_coe: float = 1.0,
        reg_alpha: float = 1.0, item_sparse_coe: float = 1.0,
        u2i_sparse_coe: float = 1.0
) -> (float, float):
    model.train()
    optim: torch.optim.Adam = torch.optim.Adam(model.parameters(), lr=lr)

    mse = nn.MSELoss()
    total_bpr_loss = 0.
    total_rec_loss = 0.
    total_pos_score = 0.
    total_neg_score = 0.
    total_h_loss = 0.
    total_u2i_sparse_loss = 0.
    total_item_sparse = 0.

    cnt = 0

    for (batch_index,
         (batch_pos_users_tensor, batch_pos_items_tensor, batch_neg_users_tensor, batch_neg_items_tensor)) \
            in enumerate(mini_batch(batch_size, pos_users_tensor, pos_items_tensor,
                                    neg_users_tensor, neg_items_tensor)):

        pos_scores, rec = model(batch_pos_users_tensor,
                                batch_pos_items_tensor, need_user_pref=True)
        neg_scores = model(batch_neg_users_tensor, batch_neg_items_tensor,
                           need_preference_grad=need_preference_grad)

        bpr_loss: torch.Tensor = BPR_loss(pos_scores, neg_scores)

        rec_loss: torch.Tensor = mse(rec, batch_pos_items_tensor)

        adj_matrix: torch.Tensor = model.get_tensor_adj_matrix()

        h_loss = cal_h_loss(model.item_dim, adj_matrix)

        dag_loss = 0.5 * h_loss * h_loss + reg_alpha * h_loss

        dim_float: float = float(model.item_dim)
        item_sparse: torch.Tensor = torch.norm(adj_matrix, p=1) / (dim_float * dim_float)

        u2i_sparse_loss: torch.Tensor = torch.norm(model.causal_graph.user2item[0].weight, p=1)

        major_loss: torch.Tensor =\
            rec_loss * rec_coe + bpr_coe * bpr_loss + dag_loss +\
            u2i_sparse_loss * u2i_sparse_coe + item_sparse * item_sparse_coe

        optim.zero_grad()
        major_loss.backward()
        optim.step()

        cnt += 1
        total_bpr_loss += float(bpr_loss)
        total_pos_score += float(torch.mean(pos_scores))
        total_neg_score += float(torch.mean(neg_scores))
        total_rec_loss += float(rec_loss)
        total_h_loss += float(h_loss)
        total_u2i_sparse_loss += float(u2i_sparse_loss)
        total_item_sparse += float(item_sparse)

    total_bpr_loss /= cnt
    total_pos_score /= cnt
    total_neg_score /= cnt
    total_rec_loss /= cnt
    total_h_loss /= cnt
    total_u2i_sparse_loss /= cnt
    total_item_sparse /= cnt

    return total_bpr_loss, total_rec_loss, total_h_loss, total_u2i_sparse_loss, total_item_sparse


def train_linear_Neural_CF(
        model: MFLinear, pos_users_tensor: torch.Tensor, pos_items_tensor: torch.Tensor,
        neg_users_tensor: torch.Tensor, neg_items_tensor: torch.Tensor,
        lr: float = 0.001, batch_size: int = 256, reg_beta: float = 0., reg_L2: float = 0.) -> (float, float):
    optim: torch.optim.Adam = torch.optim.Adam(model.parameters(), lr=lr)
    model.train()
    total_bpr_loss = 0.
    total_pos_score = 0.
    total_neg_score = 0.

    cnt = 0

    for (batch_index,
         (batch_pos_users_tensor, batch_pos_items_tensor, batch_neg_users_tensor, batch_neg_items_tensor)) \
            in enumerate(mini_batch(batch_size, pos_users_tensor, pos_items_tensor,
                                    neg_users_tensor, neg_items_tensor)):

        pos_scores: torch.Tensor = model(batch_pos_users_tensor, batch_pos_items_tensor)
        neg_scores: torch.Tensor = model(batch_neg_users_tensor, batch_neg_items_tensor)

        L1: torch.Tensor = torch.tensor(0., device=next(model.parameters()).device)
        for para in model.parameters():
            L1 += torch.norm(para, p=1)

        L2: torch.Tensor = torch.tensor(0., device=next(model.parameters()).device)
        for para in model.parameters():
            L2 += torch.norm(para, p=2)

        bpr_loss: torch.Tensor = BPR_loss(pos_scores, neg_scores)

        major_loss: torch.Tensor = bpr_loss + L1 * reg_beta + L2 * reg_L2

        optim.zero_grad()
        major_loss.backward()
        optim.step()

        cnt += 1
        total_bpr_loss += float(bpr_loss)
        total_pos_score += float(torch.mean(pos_scores))
        total_neg_score += float(torch.mean(neg_scores))

    return total_bpr_loss / cnt, total_pos_score / cnt, total_neg_score / cnt
